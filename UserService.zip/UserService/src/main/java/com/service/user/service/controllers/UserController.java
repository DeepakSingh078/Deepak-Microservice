package com.service.user.service.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.service.user.service.entities.User;
import com.service.user.service.services.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    private Logger logger = LoggerFactory.getLogger(UserController.class);

    //create
    @PostMapping("/")
    public ResponseEntity<User> createUser(@RequestBody User user) {
    	
		if (user != null && user.getName().isEmpty()) {
			User user1 = userService.saveUser(user);
			logger.info("user Date Created  -> : {}", user1);
			return ResponseEntity.status(HttpStatus.CREATED).body(user1);
		} else {
			try {
				throw new Exception();
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Not Able to create User Date -> : {}", user);
			}

		}

		return (ResponseEntity<User>) ResponseEntity.status(HttpStatus.NO_CONTENT).body(user);
        
    }

    //single user get
    @GetMapping("/{userId}")
    public ResponseEntity<User> getSingleUser(@PathVariable("userId") String userId) {
		User user = null;
		if (userId != null) {
			logger.info("Get Single User Handler: UserController");
			user = userService.getUser(userId);
			return ResponseEntity.ok(user);
		} else {
			try {
				throw new Exception();
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Not Able to Find Single  -> : {}", userId);
			}

		}

		return (ResponseEntity<User>) ResponseEntity.ok(user);

    }
    
    //all user get
    @GetMapping("/")
    public ResponseEntity<List<User>> getAllUser() {
        List<User> allUser = userService.getAllUser();
        return ResponseEntity.ok(allUser);
    }
    
    
    @PutMapping("/{userId}")
	public ResponseEntity<User> updateUser(@RequestBody User user, @PathVariable("userId") Integer uid) {
		User updatedUser = this.userService.updateUser(user, uid);
		return ResponseEntity.ok(updatedUser);
	}
    
    @DeleteMapping("/{userId}")
	public ResponseEntity<User> deleteUser(@PathVariable("userId") Integer uid) {
		this.userService.deleteUser(uid);
		return new ResponseEntity("Base on ID User is successfull delete", HttpStatus.OK);
	}
}
