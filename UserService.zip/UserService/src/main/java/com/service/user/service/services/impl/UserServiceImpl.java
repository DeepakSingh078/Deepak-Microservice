package com.service.user.service.services.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.service.user.service.entities.Rating;
import com.service.user.service.entities.User;
import com.service.user.service.repositories.UserRepository;
import com.service.user.service.services.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;

     

    private Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Override
    public User saveUser(User user) {
        //generate  unique userid
        String randomUserId = UUID.randomUUID().toString();
        user.setUserId(randomUserId);
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUser() {
        //implement RATING SERVICE CALL: USING REST TEMPLATE
        return userRepository.findAll();
    }

    //get single user
    @Override
    public User getUser(String userId) {
        //get user from database with the help  of user repository
        User user = userRepository.findById(userId).orElseThrow();
        // fetch rating of the above  user from RATING SERVICE
        //http://localhost:8082/ratings/users/47e38dac-c7d0-4c40-8582-11d15f185fad

        Rating[] ratingsOfUser = restTemplate.getForObject("http://localhost:8082/ratings/users/" + user.getUserId(), Rating[].class);
        logger.info("{} ", ratingsOfUser);
        List<Rating> ratings = Arrays.stream(ratingsOfUser).toList();
        user.setRatings(ratings);

        return user;
    }

	@Override
	public void deleteUser(Integer userId) {
		userRepository.deleteById(userId.toString());
		
	}

	@Override
	public User updateUser(User user, Integer userId) {
		User updatedUserInfo = null;
		Optional<User> usr = userRepository.findById(userId.toString());
		if (usr.isPresent()) {
			User updateUser = usr.get();
			updateUser.setUserId(user.getUserId());
			updateUser.setName(user.getName());
			updateUser.setEmail(user.getEmail());
			updateUser.setRatings(user.getRatings());
			updatedUserInfo = userRepository.save(updateUser);
		}
		return updatedUserInfo;
	}
}
