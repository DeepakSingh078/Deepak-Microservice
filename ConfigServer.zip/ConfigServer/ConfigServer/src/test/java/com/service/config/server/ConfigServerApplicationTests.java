package com.service.config.server;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServerApplicationTests {

	/*
	 * @Test void contextLoads() { }
	 */

}
